import java.util.Scanner;

public class Main {
    // Проект 3.
    //Используйте foreach.
    //Дан Enum месяцев. Пользователь вводит имя текущего месяца в консоль.
    // Программа должна вывести все месяцы, кроме того, что ввёл пользователь.
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите название текущего месяца: ");
        String month = scanner.nextLine().toUpperCase();
        Monat month1 = Monat.valueOf(month);

        System.out.println("Названия всех остальных месяцев: ");
        for (Monat monat : Monat.values()) {
            if (monat != month1) {
                System.out.print(monat.name() + " ");
            }
        }
    }
}