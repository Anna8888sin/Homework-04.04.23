import java.util.Random;

public class Main {
    // Напиши программу, которая моделирует ситуацию.
    //Ты попросил друзей скинуться на подарок на твой День Рождения.
    // Каждый друг случайным образом может подарить тебе одну купюру
    // номиналом 500, 1000, 2000 или 5000 рублей. Твоя цель - новенький игровой ПК,
    // который стоит 100 000 рублей.
    //Как только друзья подарят тебе нужную сумму (или даже чуть больше),
    // останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
            public static void main(String[] args) {
                int total = 0;
                int needSumma = 100000;
                Random random = new Random();

                while (total < needSumma) {
                    System.out.println("Уже собрали: " + total);
                    int a = 0;
                    int randomInt = random.nextInt(4);
                    switch (randomInt) {
                        case 0:
                            a = 500;
                            break;
                        case 1:
                            a = 1000;
                            break;
                        case 2:
                            a = 2000;
                            break;
                        case 3:
                            a = 5000;
                            break;
                    }
                    total += a;
                }

                System.out.println("Ура! Друзья собрали нужную сумму в " + total + " рублей!");
                System.out.println("Приглашаю в лучший бар города!");
            }
    }


