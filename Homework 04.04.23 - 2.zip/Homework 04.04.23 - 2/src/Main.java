import java.util.Scanner;

public class Main {
    // Проект 2. Используйте for.
    //Необходимо суммировать все нечётные целые числа в диапазоне, введённом пользователем.
    // Пользователь указывает нижнюю и верхнюю границу диапазона.
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Укажите нижнюю и верхнюю границу диапазона числами :");
        int n = scanner.nextInt();
        int p = scanner.nextInt();
        int sum = 0;

        for (int i = n; i <= p; i++) {
            if (i % 2 == 1){
                sum += i;
            }
        }
        System.out.println("Сумма нечетных чисел в заданном диапазоне равна " + sum);

    }
}